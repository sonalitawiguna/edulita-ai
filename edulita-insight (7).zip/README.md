# Edulita Insight - Platform Pendidikan AI

Platform edukatif berbasis chatbot AI multimodal untuk meningkatkan mutu pendidikan di Indonesia.

## 🚀 Quick Start

### Prerequisites
- Node.js 18+ 
- npm atau yarn
- Google AI Studio API Key
- Supabase Account (opsional untuk development)

### Installation

1. **Clone atau download project ini**
2. **Install dependencies:**
   \`\`\`bash
   npm install
   \`\`\`

3. **Setup environment variables:**
   \`\`\`bash
   cp .env.local.example .env.local
   \`\`\`
   
   Edit `.env.local` dan tambahkan:
   \`\`\`env
   # Google AI Studio (WAJIB)
   GOOGLE_GENERATIVE_AI_API_KEY=your_google_ai_api_key_here
   
   # Supabase (Opsional untuk development)
   NEXT_PUBLIC_SUPABASE_URL=your_supabase_url
   NEXT_PUBLIC_SUPABASE_ANON_KEY=your_supabase_anon_key
   \`\`\`

4. **Jalankan development server:**
   \`\`\`bash
   npm run dev
   \`\`\`

5. **Buka browser dan akses:**
   \`\`\`
   http://localhost:3000
   \`\`\`

## 🔑 Cara Mendapatkan API Keys

### Google AI Studio API Key (WAJIB)
1. Kunjungi [Google AI Studio](https://makersuite.google.com/app/apikey)
2. Login dengan akun Google
3. Klik "Create API Key"
4. Copy API key dan paste ke `.env.local`

### Supabase Setup (Opsional)
1. Kunjungi [Supabase](https://supabase.com)
2. Buat project baru
3. Copy URL dan Anon Key dari Settings > API
4. Jalankan SQL scripts di `scripts/` folder

## 👥 Login Credentials (Development Mode)

Untuk testing, Anda bisa menggunakan kredensial apapun:

**Siswa:**
- Email: `siswa@demo.com`
- Password: `password123`
- Role: Siswa

**Guru:**
- Email: `guru@demo.com`
- Password: `password123`
- Role: Guru

**Kepala Sekolah:**
- Email: `kepsek@demo.com`
- Password: `password123`
- Role: Kepala Sekolah

## 🎯 Fitur Utama

- 🤖 **AI Chatbot** dengan Google Gemini
- 📚 **Multi-Role Dashboard** (Siswa, Guru, Kepala Sekolah, dll)
- 📄 **Upload & Analisis Dokumen**
- 🧠 **Generator Kuis AI**
- 📊 **Visualisasi Data Pembelajaran**
- 🔐 **Sistem Autentikasi Multi-Role**

## 🛠️ Development Commands

\`\`\`bash
# Install dependencies
npm install

# Start development server
npm run dev

# Build for production
npm run build

# Start production server
npm start

# Run linting
npm run lint
\`\`\`

## 📁 Project Structure

\`\`\`
edulita-insight/
├── app/                    # Next.js App Router
│   ├── dashboard/         # Dashboard pages
│   ├── layout.tsx         # Root layout
│   └── page.tsx          # Landing page
├── components/            # React components
│   ├── auth/             # Authentication components
│   ├── chatbot/          # AI Chatbot
│   ├── dashboards/       # Role-specific dashboards
│   ├── file-upload/      # File upload functionality
│   ├── quiz/             # Quiz generator
│   └── ui/               # UI components (shadcn/ui)
├── lib/                  # Utilities and configurations
│   ├── database.ts       # Database operations
│   └── supabase.ts       # Supabase client
├── scripts/              # Database scripts
└── hooks/                # Custom React hooks
\`\`\`

## 🔧 Troubleshooting

### Error: "Google AI API key not configured"
- Pastikan `GOOGLE_GENERATIVE_AI_API_KEY` ada di `.env.local`
- Restart development server setelah menambah environment variable

### Error: "Module not found"
- Jalankan `npm install` untuk install dependencies
- Pastikan Node.js versi 18+

### Chatbot tidak merespons
- Periksa API key Google AI Studio
- Cek console browser untuk error messages
- Pastikan koneksi internet stabil

### Database errors (jika menggunakan Supabase)
- Periksa Supabase URL dan keys
- Jalankan SQL scripts di Supabase dashboard
- Pastikan RLS policies sudah disetup

## 📞 Support

Jika mengalami masalah, periksa:
1. Console browser (F12) untuk error messages
2. Terminal untuk server errors
3. Network tab untuk API call failures

## 🎓 Demo Accounts

Aplikasi mendukung mode development dengan mock authentication. Anda bisa login dengan email dan password apapun, pilih role yang diinginkan untuk testing fitur yang berbeda.
