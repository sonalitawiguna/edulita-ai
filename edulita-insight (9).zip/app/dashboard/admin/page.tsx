import { AdminDashboard } from "@/components/dashboards/admin-dashboard"

export default function AdminDashboardPage() {
  return <AdminDashboard />
}
