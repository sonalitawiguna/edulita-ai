import { DepartmentDashboard } from "@/components/dashboards/department-dashboard"

export default function DepartmentDashboardPage() {
  return <DepartmentDashboard />
}
