import { StudentDashboard } from "@/components/dashboards/student-dashboard"

export default function StudentDashboardPage() {
  return <StudentDashboard />
}
